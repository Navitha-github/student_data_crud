import { Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-create-student',
  imports: [FormsModule, ReactiveFormsModule, RouterLink],
  templateUrl: './create-student.component.html',
  styleUrl: './create-student.component.css'
})
export class CreateStudentComponent {

  stname: string = ''; // Student Name
  roll: string = '';   // Roll No
  mobile: string = ''; // Mobile No
  course: string = ''; // Course
  address: string = ''; // Address

  constructor() {}

  save() {
    console.log('Student Details:', {
      name: this.stname,
      rollNo: this.roll,
      mobile: this.mobile,
      course: this.course,
      address: this.address
    });
  }
}
