import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';


@Component({
  selector: 'app-student-list',
  imports: [CommonModule, RouterLink],
  templateUrl: './student-list.component.html',
  styleUrl: './student-list.component.css'
})
export class StudentListComponent implements OnInit{

  constructor() {

  }

  students = [
    {
      name: "navitha",
      mobile: "3243252626",
      rollNo:"ng123",
      course:"b.tech",
      address:"chennai"
    },
    {
      name: "anil",
      mobile: "875632567",
      rollNo:"ng456",
      course:"b.pharmacy",
      address:"bangalore"
    }
  ];

  ngOnInit(): void {
    
  }

}
